 "use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Project = {
  id: string; title: string; slug: string; category: "web"|"ai"|"creative"; summary: string;
  technologies: string[]; live_url: string|null; repo_url: string|null; status: "Live"|"In development"|"Concept"|"Experiment";
  featured: boolean; published: boolean; sort_order: number; created_at: string;
};
type Message = { id: string; name: string; email: string; topic: string; message: string; is_read: boolean; created_at: string };
type ProjectForm = Omit<Project, "id"|"created_at"|"technologies"> & { id?: string; technologiesText: string };

const blankForm: ProjectForm = { title: "", slug: "", category: "web", summary: "", technologiesText: "", live_url: "", repo_url: "", status: "Concept", featured: false, published: true, sort_order: 0 };

async function api(url: string, init?: RequestInit) {
  const response = await fetch(url, { ...init, headers: { "Content-Type": "application/json", ...(init?.headers || {}) } });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Request failed.");
  return result;
}

export function AdminDashboard() {
  const [authenticated, setAuthenticated] = useState<boolean|null>(null);
  const [password, setPassword] = useState("");
  const [projects, setProjects] = useState<Project[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [tab, setTab] = useState<"projects"|"messages">("projects");
  const [form, setForm] = useState<ProjectForm>(blankForm);
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  const refresh = useCallback(async () => {
    const [p, m] = await Promise.all([api("/api/projects"), api("/api/admin/messages")]);
    setProjects(p.projects || []);
    setMessages(m.messages || []);
  }, []);

  useEffect(() => {
    api("/api/auth/me").then(async r => {
      setAuthenticated(Boolean(r.authenticated));
      if (r.authenticated) {
        try { await refresh(); } catch (e) { setNotice(e instanceof Error ? e.message : "Could not load dashboard."); }
      }
    }).catch(() => setAuthenticated(false));
  }, [refresh]);

  async function login(event: FormEvent) {
    event.preventDefault(); setBusy(true); setNotice("");
    try {
      await api("/api/auth/login", { method: "POST", body: JSON.stringify({ password }) });
      setPassword(""); setAuthenticated(true); await refresh(); setNotice("Signed in successfully.");
    } catch (e) { setNotice(e instanceof Error ? e.message : "Login failed."); }
    finally { setBusy(false); }
  }

  async function logout() {
    await api("/api/auth/logout", { method: "POST", body: "{}" });
    setAuthenticated(false); setProjects([]); setMessages([]); setNotice("You have signed out.");
  }

  function editProject(project: Project) {
    setForm({ ...project, technologiesText: (project.technologies || []).join(", "), live_url: project.live_url || "", repo_url: project.repo_url || "" });
    setEditing(true); setTab("projects"); window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function newProject() { setForm({ ...blankForm }); setEditing(false); }

  async function saveProject(event: FormEvent) {
    event.preventDefault(); setBusy(true); setNotice("");
    const payload = { ...form, technologies: form.technologiesText.split(",").map(s => s.trim()).filter(Boolean), live_url: form.live_url || null, repo_url: form.repo_url || null };
    delete (payload as Partial<ProjectForm>).technologiesText;
    try {
      await api("/api/projects", { method: editing ? "PUT" : "POST", body: JSON.stringify(payload) });
      await refresh(); newProject(); setNotice(editing ? "Project updated." : "Project created.");
    } catch (e) { setNotice(e instanceof Error ? e.message : "Could not save project."); }
    finally { setBusy(false); }
  }

  async function deleteProject(project: Project) {
    if (!window.confirm(`Delete “${project.title}”? This cannot be undone.`)) return;
    try { await api("/api/projects", { method: "DELETE", body: JSON.stringify({ id: project.id }) }); await refresh(); setNotice("Project deleted."); }
    catch (e) { setNotice(e instanceof Error ? e.message : "Could not delete project."); }
  }

  async function toggleMessage(message: Message) {
    try { await api("/api/admin/messages", { method: "PATCH", body: JSON.stringify({ id: message.id, is_read: !message.is_read }) }); await refresh(); }
    catch (e) { setNotice(e instanceof Error ? e.message : "Could not update message."); }
  }

  async function deleteMessage(message: Message) {
    if (!window.confirm("Delete this contact message?")) return;
    try { await api("/api/admin/messages", { method: "DELETE", body: JSON.stringify({ id: message.id }) }); await refresh(); setNotice("Message deleted."); }
    catch (e) { setNotice(e instanceof Error ? e.message : "Could not delete message."); }
  }

  if (authenticated === null) return <div className="admin-loading">Checking admin session…</div>;
  if (!authenticated) return <div className="admin-login-card"><a className="brand" href="/"><span className="brand-mark">A<span>.</span></span><span className="brand-name">ALBINUS SOREN<small>PRIVATE ADMIN</small></span></a><p className="kicker">SECURE AREA</p><h1>Welcome back.</h1><p className="admin-muted">Sign in to manage portfolio projects and contact messages.</p><form onSubmit={login} className="admin-login-form"><label htmlFor="admin-password">Admin password</label><input id="admin-password" type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required /><button className="button primary" disabled={busy}>{busy ? "Signing in…" : "Sign in"} ↗</button></form>{notice && <p className="admin-notice error">{notice}</p>}<a className="admin-back" href="/">← Back to portfolio</a></div>;

  return <div className="admin-shell">
    <header className="admin-header"><a className="brand" href="/"><span className="brand-mark">A<span>.</span></span><span className="brand-name">ALBINUS SOREN<small>ADMIN CONSOLE</small></span></a><div className="admin-header-actions"><a href="/" target="_blank">View site ↗</a><button className="button secondary small" onClick={logout}>Sign out</button></div></header>
    <div className="admin-welcome"><div><p className="kicker">PORTFOLIO MANAGEMENT</p><h1>Dashboard<span className="gradient-text">.</span></h1><p className="admin-muted">Manage published work and messages from one place.</p></div><div className="admin-stats"><div><strong>{projects.length}</strong><span>Projects</span></div><div><strong>{projects.filter(p => p.published).length}</strong><span>Published</span></div><div><strong>{messages.filter(m => !m.is_read).length}</strong><span>Unread messages</span></div></div></div>
    {notice && <div className={`admin-notice ${notice.toLowerCase().includes("could not") || notice.toLowerCase().includes("failed") || notice.toLowerCase().includes("invalid") ? "error" : ""}`} role="status">{notice}<button onClick={() => setNotice("")} aria-label="Dismiss">×</button></div>}
    <div className="admin-tabs"><button className={tab==="projects"?"active":""} onClick={() => setTab("projects")}>Projects <span>{projects.length}</span></button><button className={tab==="messages"?"active":""} onClick={() => setTab("messages")}>Inbox <span>{messages.length}</span></button></div>
    {tab === "projects" ? <div className="admin-project-layout">
      <section className="admin-panel project-editor"><div className="panel-heading"><div><p className="kicker">{editing ? "EDIT EXISTING" : "ADD SOMETHING NEW"}</p><h2>{editing ? "Edit project" : "New project"}</h2></div>{editing && <button className="text-button" onClick={newProject}>Cancel edit</button>}</div>
        <form onSubmit={saveProject}>
          <div className="admin-form-grid"><div className="form-row"><label htmlFor="p-title">Project title *</label><input id="p-title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required minLength={2} maxLength={100}/></div><div className="form-row"><label htmlFor="p-slug">URL slug *</label><input id="p-slug" value={form.slug} onChange={e=>setForm({...form,slug:e.target.value.toLowerCase().replace(/[^a-z0-9-]/g,"")})} placeholder="my-project" required pattern="[a-z0-9]+(-[a-z0-9]+)*" maxLength={100}/></div>
          <div className="form-row"><label htmlFor="p-category">Category *</label><select id="p-category" value={form.category} onChange={e=>setForm({...form,category:e.target.value as ProjectForm["category"]})}><option value="web">Web & Apps</option><option value="ai">AI & SaaS</option><option value="creative">Creative</option></select></div><div className="form-row"><label htmlFor="p-status">Status</label><select id="p-status" value={form.status} onChange={e=>setForm({...form,status:e.target.value as ProjectForm["status"]})}><option>Live</option><option>In development</option><option>Concept</option><option>Experiment</option></select></div></div>
          <div className="form-row"><label htmlFor="p-summary">Description *</label><textarea id="p-summary" value={form.summary} onChange={e=>setForm({...form,summary:e.target.value})} required minLength={5} maxLength={600} rows={3}/></div>
          <div className="form-row"><label htmlFor="p-tech">Technologies (comma-separated)</label><input id="p-tech" value={form.technologiesText} onChange={e=>setForm({...form,technologiesText:e.target.value})} placeholder="Next.js, TypeScript, Supabase"/></div>
          <div className="admin-form-grid"><div className="form-row"><label htmlFor="p-live">Live URL</label><input id="p-live" type="url" value={form.live_url||""} onChange={e=>setForm({...form,live_url:e.target.value})} placeholder="https://..."/></div><div className="form-row"><label htmlFor="p-repo">Repository URL</label><input id="p-repo" type="url" value={form.repo_url||""} onChange={e=>setForm({...form,repo_url:e.target.value})} placeholder="https://github.com/..."/></div></div>
          <div className="form-row"><label htmlFor="p-order">Sort order (smaller appears first)</label><input id="p-order" type="number" min="0" max="10000" value={form.sort_order} onChange={e=>setForm({...form,sort_order:Number(e.target.value)})}/></div>
          <div className="check-row"><label><input type="checkbox" checked={form.featured} onChange={e=>setForm({...form,featured:e.target.checked})}/> Featured project</label><label><input type="checkbox" checked={form.published} onChange={e=>setForm({...form,published:e.target.checked})}/> Published on website</label></div>
          <button className="button primary full" disabled={busy}>{busy ? "Saving…" : editing ? "Save changes" : "Create project"} <span>↗</span></button>
        </form>
      </section>
      <section className="admin-panel"><div className="panel-heading"><div><p className="kicker">YOUR WORK</p><h2>Projects</h2></div><button className="button secondary small" onClick={newProject}>+ New</button></div>
        <div className="admin-project-list">{projects.map(project=><article className="admin-project-row" key={project.id}><div className="admin-project-initial">{project.title.slice(0,1).toUpperCase()}</div><div className="admin-project-main"><strong>{project.title}</strong><span>/{project.slug} · {project.status}</span><div className="admin-badges"><span className={project.published?"published":"unpublished"}>{project.published?"Published":"Hidden"}</span>{project.featured&&<span>Featured</span>}</div></div><div className="row-actions"><button onClick={()=>editProject(project)}>Edit</button><button className="danger-link" onClick={()=>deleteProject(project)}>Delete</button></div></article>)}{projects.length===0&&<p className="admin-muted">No projects yet. Add your first one.</p>}</div>
      </section>
    </div> : <section className="admin-panel inbox-panel"><div className="panel-heading"><div><p className="kicker">CONTACT FORM SUBMISSIONS</p><h2>Inbox</h2></div><span className="inbox-count">{messages.length} messages</span></div>{messages.length===0?<div className="empty-inbox"><span>✉</span><h3>Your inbox is clear.</h3><p>Contact form submissions will appear here.</p></div>:<div className="messages-list">{messages.map(message=><article className={`message-card ${message.is_read?"read":""}`} key={message.id}><div className="message-head"><div><strong>{message.name}</strong><a href={`mailto:${encodeURIComponent(message.email)}?subject=${encodeURIComponent("Re: "+message.topic)}`}>{message.email}</a></div><time>{new Date(message.created_at).toLocaleString()}</time></div><span className="message-topic">{message.topic}</span><p>{message.message}</p><div className="message-actions"><button onClick={()=>toggleMessage(message)}>{message.is_read?"Mark unread":"Mark read"}</button><button className="danger-link" onClick={()=>deleteMessage(message)}>Delete</button></div></article>)}</div>}</section>}
    <footer className="admin-footer"><span>Private portfolio dashboard</span><span>Session expires after 8 hours</span></footer>
  </div>;
}